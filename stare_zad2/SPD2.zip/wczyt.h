//
// Created by adam9 on 07.05.2025.
//

#ifndef SPD2_WCZYT_H
#define SPD2_WCZYT_H

#include <iostream>
#include "rozwiazanie.h"
#include <fstream>

bool wczytywanie(const std::string &nazwaPliku, problem &prob, int LiczbaMaszyn);

#endif //SPD2_WCZYT_H
